--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.track DROP CONSTRAINT fk_track_mediatype;
ALTER TABLE ONLY public.track DROP CONSTRAINT fk_track_genero;
ALTER TABLE ONLY public.track DROP CONSTRAINT fk_track_album;
ALTER TABLE ONLY public.playlisttrack DROP CONSTRAINT fk_playlisttrack_track;
ALTER TABLE ONLY public.playlisttrack DROP CONSTRAINT fk_playlisttrack_playlist;
ALTER TABLE ONLY public.invoiceline DROP CONSTRAINT fk_invoiceline_track;
ALTER TABLE ONLY public.invoiceline DROP CONSTRAINT fk_invoiceline_invoice;
ALTER TABLE ONLY public.invoice DROP CONSTRAINT fk_invoice_customer;
ALTER TABLE ONLY public.employee DROP CONSTRAINT fk_employee_employee;
ALTER TABLE ONLY public.customer DROP CONSTRAINT fk_customer_employee;
ALTER TABLE ONLY public.album DROP CONSTRAINT fk_album_artist;
ALTER TABLE ONLY public.track DROP CONSTRAINT track_pkey;
ALTER TABLE ONLY public.playlisttrack DROP CONSTRAINT playlisttrack_pkey;
ALTER TABLE ONLY public.playlist DROP CONSTRAINT playlist_pkey;
ALTER TABLE ONLY public.mediatype DROP CONSTRAINT mediatype_pkey;
ALTER TABLE ONLY public.invoiceline DROP CONSTRAINT invoiceline_pkey;
ALTER TABLE ONLY public.invoice DROP CONSTRAINT invoice_pkey;
ALTER TABLE ONLY public.genero DROP CONSTRAINT genero_pkey;
ALTER TABLE ONLY public.employee DROP CONSTRAINT employee_pkey;
ALTER TABLE ONLY public.customer DROP CONSTRAINT customer_pkey;
ALTER TABLE ONLY public.artist DROP CONSTRAINT artist_pkey;
ALTER TABLE ONLY public.album DROP CONSTRAINT album_pkey;
DROP VIEW public.total_ventas_mes_vendedor;
DROP VIEW public.top5_vendidas_genero;
DROP VIEW public.top20_canciones_duracion_tipo;
DROP TABLE public.track;
DROP TABLE public.playlisttrack;
DROP TABLE public.playlist;
DROP TABLE public.mediatype;
DROP TABLE public.genero;
DROP TABLE public.employee;
DROP VIEW public.clientes_mas_compras;
DROP TABLE public.invoiceline;
DROP TABLE public.invoice;
DROP TABLE public.customer;
DROP TABLE public.artist;
DROP TABLE public.album;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: album; Type: TABLE; Schema: public; Owner: admin_user; Tablespace: 
--

CREATE TABLE album (
    albumid integer NOT NULL,
    title character varying(100),
    artistid integer
);


ALTER TABLE public.album OWNER TO admin_user;

--
-- Name: artist; Type: TABLE; Schema: public; Owner: admin_user; Tablespace: 
--

CREATE TABLE artist (
    artistid integer NOT NULL,
    name character varying(100)
);


ALTER TABLE public.artist OWNER TO admin_user;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: admin_user; Tablespace: 
--

CREATE TABLE customer (
    customerid integer NOT NULL,
    firstname character varying(80),
    lastname character varying(80),
    company character varying(80),
    address character varying(100),
    city character varying(50),
    state character varying(100),
    country character varying(100),
    postalcode character varying(15),
    phone character varying(50),
    fax character varying(50),
    email character varying(100),
    supportrepid integer
);


ALTER TABLE public.customer OWNER TO admin_user;

--
-- Name: invoice; Type: TABLE; Schema: public; Owner: admin_user; Tablespace: 
--

CREATE TABLE invoice (
    invoiceid integer NOT NULL,
    customerid integer,
    invoicedate timestamp without time zone,
    billingaddress character varying(100),
    billingcity character varying(100),
    billingstate character varying(100),
    billingcountry character varying(100),
    billingpostalcode character varying(15),
    total money
);


ALTER TABLE public.invoice OWNER TO admin_user;

--
-- Name: invoiceline; Type: TABLE; Schema: public; Owner: admin_user; Tablespace: 
--

CREATE TABLE invoiceline (
    invoicelineid integer NOT NULL,
    invoiceid integer,
    trackid integer,
    unitprice money,
    quantity smallint
);


ALTER TABLE public.invoiceline OWNER TO admin_user;

--
-- Name: clientes_mas_compras; Type: VIEW; Schema: public; Owner: admin_user
--

CREATE VIEW clientes_mas_compras AS
 SELECT c.firstname,
    c.lastname,
    count(inv_l.quantity) AS c_canciones
   FROM customer c,
    invoice inv,
    invoiceline inv_l
  WHERE ((c.customerid = inv.customerid) AND (inv.invoiceid = inv_l.invoiceid))
  GROUP BY c.firstname, c.lastname
  ORDER BY count(inv_l.quantity) DESC
 LIMIT 3;


ALTER TABLE public.clientes_mas_compras OWNER TO admin_user;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: admin_user; Tablespace: 
--

CREATE TABLE employee (
    employeeid integer NOT NULL,
    lastname character varying(80),
    firstname character varying(80),
    title character varying(80),
    reportsto integer,
    birthdate timestamp without time zone,
    hiredate timestamp without time zone,
    address character varying(100),
    city character varying(100),
    state character varying(100),
    country character varying(100),
    postalcode character varying(15),
    phone character varying(50),
    fax character varying(50),
    email character varying(100)
);


ALTER TABLE public.employee OWNER TO admin_user;

--
-- Name: genero; Type: TABLE; Schema: public; Owner: admin_user; Tablespace: 
--

CREATE TABLE genero (
    generoid integer NOT NULL,
    name character varying(100)
);


ALTER TABLE public.genero OWNER TO admin_user;

--
-- Name: mediatype; Type: TABLE; Schema: public; Owner: admin_user; Tablespace: 
--

CREATE TABLE mediatype (
    mediatypeid integer NOT NULL,
    name character varying(100)
);


ALTER TABLE public.mediatype OWNER TO admin_user;

--
-- Name: playlist; Type: TABLE; Schema: public; Owner: admin_user; Tablespace: 
--

CREATE TABLE playlist (
    playlistid integer NOT NULL,
    name character varying(100)
);


ALTER TABLE public.playlist OWNER TO admin_user;

--
-- Name: playlisttrack; Type: TABLE; Schema: public; Owner: admin_user; Tablespace: 
--

CREATE TABLE playlisttrack (
    playlistid integer NOT NULL,
    trackid integer NOT NULL
);


ALTER TABLE public.playlisttrack OWNER TO admin_user;

--
-- Name: track; Type: TABLE; Schema: public; Owner: admin_user; Tablespace: 
--

CREATE TABLE track (
    trackid integer NOT NULL,
    name character varying(200),
    albumid integer,
    mediatypeid integer,
    generoid integer,
    composer character varying(200),
    milliseconds integer,
    bytes integer,
    unitprice money
);


ALTER TABLE public.track OWNER TO admin_user;

--
-- Name: top20_canciones_duracion_tipo; Type: VIEW; Schema: public; Owner: admin_user
--

CREATE VIEW top20_canciones_duracion_tipo AS
 SELECT t_r.trackid,
    t_r.name AS name_track,
    t_r.milliseconds,
    mt_r.name
   FROM mediatype mt_r,
    track t_r
  WHERE ((t_r.trackid IN ( SELECT r.trackid
           FROM ( SELECT t.trackid,
                    t.name,
                    t.milliseconds,
                    mt.name
                   FROM track t,
                    mediatype mt
                  WHERE ((t.mediatypeid = mt.mediatypeid) AND (mt.mediatypeid = mt_r.mediatypeid))
                  ORDER BY mt.name, t.milliseconds DESC
                 LIMIT 20) r(trackid, name, milliseconds, name_1))) AND (t_r.mediatypeid = mt_r.mediatypeid))
  ORDER BY mt_r.name, t_r.milliseconds DESC;


ALTER TABLE public.top20_canciones_duracion_tipo OWNER TO admin_user;

--
-- Name: top5_vendidas_genero; Type: VIEW; Schema: public; Owner: admin_user
--

CREATE VIEW top5_vendidas_genero AS
 SELECT gi.generoid,
    gi.name AS genero,
    tr.name AS tema,
    count(iv.quantity) AS vend
   FROM genero gi,
    invoiceline iv,
    track tr
  WHERE ((((tr.name)::text IN ( SELECT r.name
           FROM ( SELECT t.name,
                    count(i.quantity) AS vendidos
                   FROM genero g,
                    track t,
                    invoiceline i
                  WHERE (((g.generoid = t.generoid) AND (t.trackid = i.trackid)) AND (g.generoid = gi.generoid))
                  GROUP BY g.generoid, g.name, t.name
                  ORDER BY g.name, count(i.quantity) DESC
                 LIMIT 5) r)) AND (gi.generoid = tr.generoid)) AND (tr.trackid = iv.trackid))
  GROUP BY gi.generoid, gi.name, tr.name
  ORDER BY gi.generoid, count(iv.quantity) DESC;


ALTER TABLE public.top5_vendidas_genero OWNER TO admin_user;

--
-- Name: total_ventas_mes_vendedor; Type: VIEW; Schema: public; Owner: admin_user
--

CREATE VIEW total_ventas_mes_vendedor AS
 SELECT e.lastname,
    e.firstname,
    date_part('year'::text, i.invoicedate) AS "año",
    to_char(i.invoicedate, 'MM'::text) AS mes,
    sum(i.total) AS sum
   FROM employee e,
    (customer c
     CROSS JOIN invoice i)
  WHERE ((e.employeeid = c.supportrepid) AND (c.customerid = i.customerid))
  GROUP BY e.lastname, e.firstname, date_part('year'::text, i.invoicedate), to_char(i.invoicedate, 'MM'::text)
  ORDER BY e.lastname, e.firstname, date_part('year'::text, i.invoicedate), to_char(i.invoicedate, 'MM'::text);


ALTER TABLE public.total_ventas_mes_vendedor OWNER TO admin_user;

--
-- Data for Name: album; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY album (albumid, title, artistid) FROM stdin;
\.
COPY album (albumid, title, artistid) FROM '$$PATH$$/2102.dat';

--
-- Data for Name: artist; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY artist (artistid, name) FROM stdin;
\.
COPY artist (artistid, name) FROM '$$PATH$$/2101.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY customer (customerid, firstname, lastname, company, address, city, state, country, postalcode, phone, fax, email, supportrepid) FROM stdin;
\.
COPY customer (customerid, firstname, lastname, company, address, city, state, country, postalcode, phone, fax, email, supportrepid) FROM '$$PATH$$/2110.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY employee (employeeid, lastname, firstname, title, reportsto, birthdate, hiredate, address, city, state, country, postalcode, phone, fax, email) FROM stdin;
\.
COPY employee (employeeid, lastname, firstname, title, reportsto, birthdate, hiredate, address, city, state, country, postalcode, phone, fax, email) FROM '$$PATH$$/2111.dat';

--
-- Data for Name: genero; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY genero (generoid, name) FROM stdin;
\.
COPY genero (generoid, name) FROM '$$PATH$$/2106.dat';

--
-- Data for Name: invoice; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY invoice (invoiceid, customerid, invoicedate, billingaddress, billingcity, billingstate, billingcountry, billingpostalcode, total) FROM stdin;
\.
COPY invoice (invoiceid, customerid, invoicedate, billingaddress, billingcity, billingstate, billingcountry, billingpostalcode, total) FROM '$$PATH$$/2109.dat';

--
-- Data for Name: invoiceline; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY invoiceline (invoicelineid, invoiceid, trackid, unitprice, quantity) FROM stdin;
\.
COPY invoiceline (invoicelineid, invoiceid, trackid, unitprice, quantity) FROM '$$PATH$$/2108.dat';

--
-- Data for Name: mediatype; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY mediatype (mediatypeid, name) FROM stdin;
\.
COPY mediatype (mediatypeid, name) FROM '$$PATH$$/2105.dat';

--
-- Data for Name: playlist; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY playlist (playlistid, name) FROM stdin;
\.
COPY playlist (playlistid, name) FROM '$$PATH$$/2103.dat';

--
-- Data for Name: playlisttrack; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY playlisttrack (playlistid, trackid) FROM stdin;
\.
COPY playlisttrack (playlistid, trackid) FROM '$$PATH$$/2104.dat';

--
-- Data for Name: track; Type: TABLE DATA; Schema: public; Owner: admin_user
--

COPY track (trackid, name, albumid, mediatypeid, generoid, composer, milliseconds, bytes, unitprice) FROM stdin;
\.
COPY track (trackid, name, albumid, mediatypeid, generoid, composer, milliseconds, bytes, unitprice) FROM '$$PATH$$/2107.dat';

--
-- Name: album_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user; Tablespace: 
--

ALTER TABLE ONLY album
    ADD CONSTRAINT album_pkey PRIMARY KEY (albumid);


--
-- Name: artist_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user; Tablespace: 
--

ALTER TABLE ONLY artist
    ADD CONSTRAINT artist_pkey PRIMARY KEY (artistid);


--
-- Name: customer_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user; Tablespace: 
--

ALTER TABLE ONLY customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customerid);


--
-- Name: employee_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user; Tablespace: 
--

ALTER TABLE ONLY employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (employeeid);


--
-- Name: genero_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user; Tablespace: 
--

ALTER TABLE ONLY genero
    ADD CONSTRAINT genero_pkey PRIMARY KEY (generoid);


--
-- Name: invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user; Tablespace: 
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (invoiceid);


--
-- Name: invoiceline_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user; Tablespace: 
--

ALTER TABLE ONLY invoiceline
    ADD CONSTRAINT invoiceline_pkey PRIMARY KEY (invoicelineid);


--
-- Name: mediatype_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user; Tablespace: 
--

ALTER TABLE ONLY mediatype
    ADD CONSTRAINT mediatype_pkey PRIMARY KEY (mediatypeid);


--
-- Name: playlist_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user; Tablespace: 
--

ALTER TABLE ONLY playlist
    ADD CONSTRAINT playlist_pkey PRIMARY KEY (playlistid);


--
-- Name: playlisttrack_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user; Tablespace: 
--

ALTER TABLE ONLY playlisttrack
    ADD CONSTRAINT playlisttrack_pkey PRIMARY KEY (playlistid, trackid);


--
-- Name: track_pkey; Type: CONSTRAINT; Schema: public; Owner: admin_user; Tablespace: 
--

ALTER TABLE ONLY track
    ADD CONSTRAINT track_pkey PRIMARY KEY (trackid);


--
-- Name: fk_album_artist; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY album
    ADD CONSTRAINT fk_album_artist FOREIGN KEY (artistid) REFERENCES artist(artistid);


--
-- Name: fk_customer_employee; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY customer
    ADD CONSTRAINT fk_customer_employee FOREIGN KEY (supportrepid) REFERENCES employee(employeeid);


--
-- Name: fk_employee_employee; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY employee
    ADD CONSTRAINT fk_employee_employee FOREIGN KEY (reportsto) REFERENCES employee(employeeid);


--
-- Name: fk_invoice_customer; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY invoice
    ADD CONSTRAINT fk_invoice_customer FOREIGN KEY (customerid) REFERENCES customer(customerid);


--
-- Name: fk_invoiceline_invoice; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY invoiceline
    ADD CONSTRAINT fk_invoiceline_invoice FOREIGN KEY (invoiceid) REFERENCES invoice(invoiceid);


--
-- Name: fk_invoiceline_track; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY invoiceline
    ADD CONSTRAINT fk_invoiceline_track FOREIGN KEY (trackid) REFERENCES track(trackid);


--
-- Name: fk_playlisttrack_playlist; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY playlisttrack
    ADD CONSTRAINT fk_playlisttrack_playlist FOREIGN KEY (playlistid) REFERENCES playlist(playlistid);


--
-- Name: fk_playlisttrack_track; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY playlisttrack
    ADD CONSTRAINT fk_playlisttrack_track FOREIGN KEY (trackid) REFERENCES track(trackid);


--
-- Name: fk_track_album; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY track
    ADD CONSTRAINT fk_track_album FOREIGN KEY (albumid) REFERENCES album(albumid);


--
-- Name: fk_track_genero; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY track
    ADD CONSTRAINT fk_track_genero FOREIGN KEY (generoid) REFERENCES genero(generoid);


--
-- Name: fk_track_mediatype; Type: FK CONSTRAINT; Schema: public; Owner: admin_user
--

ALTER TABLE ONLY track
    ADD CONSTRAINT fk_track_mediatype FOREIGN KEY (mediatypeid) REFERENCES mediatype(mediatypeid);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: album; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE album FROM PUBLIC;
REVOKE ALL ON TABLE album FROM admin_user;
GRANT ALL ON TABLE album TO admin_user;
GRANT SELECT ON TABLE album TO uasb_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE album TO operator_user;


--
-- Name: artist; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE artist FROM PUBLIC;
REVOKE ALL ON TABLE artist FROM admin_user;
GRANT ALL ON TABLE artist TO admin_user;
GRANT SELECT ON TABLE artist TO uasb_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE artist TO operator_user;


--
-- Name: customer; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE customer FROM PUBLIC;
REVOKE ALL ON TABLE customer FROM admin_user;
GRANT ALL ON TABLE customer TO admin_user;
GRANT SELECT ON TABLE customer TO uasb_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE customer TO operator_user;


--
-- Name: invoice; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE invoice FROM PUBLIC;
REVOKE ALL ON TABLE invoice FROM admin_user;
GRANT ALL ON TABLE invoice TO admin_user;
GRANT SELECT ON TABLE invoice TO uasb_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE invoice TO operator_user;


--
-- Name: invoiceline; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE invoiceline FROM PUBLIC;
REVOKE ALL ON TABLE invoiceline FROM admin_user;
GRANT ALL ON TABLE invoiceline TO admin_user;
GRANT SELECT ON TABLE invoiceline TO uasb_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE invoiceline TO operator_user;


--
-- Name: clientes_mas_compras; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE clientes_mas_compras FROM PUBLIC;
REVOKE ALL ON TABLE clientes_mas_compras FROM admin_user;
GRANT ALL ON TABLE clientes_mas_compras TO admin_user;
GRANT SELECT ON TABLE clientes_mas_compras TO uasb_user;
GRANT SELECT ON TABLE clientes_mas_compras TO test_user;


--
-- Name: employee; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE employee FROM PUBLIC;
REVOKE ALL ON TABLE employee FROM admin_user;
GRANT ALL ON TABLE employee TO admin_user;
GRANT SELECT ON TABLE employee TO uasb_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE employee TO operator_user;


--
-- Name: genero; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE genero FROM PUBLIC;
REVOKE ALL ON TABLE genero FROM admin_user;
GRANT ALL ON TABLE genero TO admin_user;
GRANT SELECT ON TABLE genero TO uasb_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE genero TO operator_user;


--
-- Name: mediatype; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE mediatype FROM PUBLIC;
REVOKE ALL ON TABLE mediatype FROM admin_user;
GRANT ALL ON TABLE mediatype TO admin_user;
GRANT SELECT ON TABLE mediatype TO uasb_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE mediatype TO operator_user;


--
-- Name: playlist; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE playlist FROM PUBLIC;
REVOKE ALL ON TABLE playlist FROM admin_user;
GRANT ALL ON TABLE playlist TO admin_user;
GRANT SELECT ON TABLE playlist TO uasb_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE playlist TO operator_user;


--
-- Name: playlisttrack; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE playlisttrack FROM PUBLIC;
REVOKE ALL ON TABLE playlisttrack FROM admin_user;
GRANT ALL ON TABLE playlisttrack TO admin_user;
GRANT SELECT ON TABLE playlisttrack TO uasb_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE playlisttrack TO operator_user;


--
-- Name: track; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE track FROM PUBLIC;
REVOKE ALL ON TABLE track FROM admin_user;
GRANT ALL ON TABLE track TO admin_user;
GRANT SELECT ON TABLE track TO uasb_user;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE track TO operator_user;


--
-- Name: top20_canciones_duracion_tipo; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE top20_canciones_duracion_tipo FROM PUBLIC;
REVOKE ALL ON TABLE top20_canciones_duracion_tipo FROM admin_user;
GRANT ALL ON TABLE top20_canciones_duracion_tipo TO admin_user;
GRANT SELECT ON TABLE top20_canciones_duracion_tipo TO uasb_user;
GRANT SELECT ON TABLE top20_canciones_duracion_tipo TO test_user;


--
-- Name: top5_vendidas_genero; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE top5_vendidas_genero FROM PUBLIC;
REVOKE ALL ON TABLE top5_vendidas_genero FROM admin_user;
GRANT ALL ON TABLE top5_vendidas_genero TO admin_user;
GRANT SELECT ON TABLE top5_vendidas_genero TO uasb_user;
GRANT SELECT ON TABLE top5_vendidas_genero TO test_user;


--
-- Name: total_ventas_mes_vendedor; Type: ACL; Schema: public; Owner: admin_user
--

REVOKE ALL ON TABLE total_ventas_mes_vendedor FROM PUBLIC;
REVOKE ALL ON TABLE total_ventas_mes_vendedor FROM admin_user;
GRANT ALL ON TABLE total_ventas_mes_vendedor TO admin_user;
GRANT SELECT ON TABLE total_ventas_mes_vendedor TO uasb_user;
GRANT SELECT ON TABLE total_ventas_mes_vendedor TO test_user;


--
-- PostgreSQL database dump complete
--

